import {UserHobbit} from './user-hobbit';

export interface Hobbit {

  idHobbit?: number;

  hobbitName?: string;

  userHobbits?: UserHobbit[];
}
