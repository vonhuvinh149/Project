import {User} from './user';

export interface TypeUser {

  idTypeUser?: number;

  typeUserName?: string;

  users?: User[];

}
