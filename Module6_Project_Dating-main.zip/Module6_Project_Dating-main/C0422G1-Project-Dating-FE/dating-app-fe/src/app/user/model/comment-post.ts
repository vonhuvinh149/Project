export interface CommentPost {
  content?: number;
  idUser?: number;
  idPost?:number;
  avatar?:String;
  name?: String
}
