export interface UserTargetKey {

  idUser?: number;

  idTarget?: number;

}
