export interface UserHobbitKey {

  idUser?: number;

  idHobbit?: number;
}
