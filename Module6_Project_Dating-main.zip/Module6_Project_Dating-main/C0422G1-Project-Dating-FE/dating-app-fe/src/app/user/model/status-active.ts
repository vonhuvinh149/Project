export interface StatusActive {
}
