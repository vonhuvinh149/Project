export interface NewFeed {
  idPost?: number,
  idUser?: number,
  media?: string,
  avatar?: string,
  time?: string,
  userName?: string,
  content?: string
  mediaArr?: string[];
  arrContent?: string[];
}
