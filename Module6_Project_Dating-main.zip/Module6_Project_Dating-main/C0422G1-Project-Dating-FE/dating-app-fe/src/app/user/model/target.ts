import {UserTarget} from './user-target';

export interface Target {

  idTarget?: number;

  targetName?: string;

  userTargets?: UserTarget[];
}
