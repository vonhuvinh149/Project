export interface GiftUserKey {

  idGift?: number;

  idSender?: number;

  idReceiver?: number;
}
