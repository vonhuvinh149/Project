export interface RoomChat {

  id?: number;

  name?: string;
}
