export interface Report {

  idReport?: number;

  nameReport?: string;
}
