import {AccountRole} from './account-role';

export interface Role {

  idRole?: number;

  roleName?: string;

  accountRoles?: AccountRole[]
}
