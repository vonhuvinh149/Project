export interface JwtRequest {
  newPassword?: string;
  password?: string
}
