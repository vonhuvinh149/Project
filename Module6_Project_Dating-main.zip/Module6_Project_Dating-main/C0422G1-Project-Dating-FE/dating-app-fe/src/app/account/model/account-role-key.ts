export interface AccountRoleKey {

  idAccount?: number;

  idRole?: number;
}
