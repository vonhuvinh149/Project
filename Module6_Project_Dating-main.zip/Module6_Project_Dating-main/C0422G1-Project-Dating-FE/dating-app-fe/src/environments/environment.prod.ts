export const environment = {
  production: true,
  //  firebaseConfig : {
  //    apiKey: "AIzaSyDnig5SGMyEPAbcWzMOoX4wFltMP-bLLCc",
  //    authDomain: "demo123-2a298.firebaseapp.com",
  //    projectId: "demo123-2a298",
  //    storageBucket: "demo123-2a298.appspot.com",
  //    messagingSenderId: "237117942136",
  //    appId: "1:237117942136:web:4e0c2c9d7f1766d53e808d"
  // }
};
