package com.codegym.dating.dto;

public interface FriendListDto {
    Integer getIdUser();
    Integer getStatus();
    String getName();
    String getGender();


}
