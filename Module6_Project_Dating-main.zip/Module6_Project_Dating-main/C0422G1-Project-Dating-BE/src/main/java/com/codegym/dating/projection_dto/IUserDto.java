package com.codegym.dating.projection_dto;

public interface IUserDto {
    int getIdUser();

    String getName();

    int getAge();

    String getAvatar();
}
