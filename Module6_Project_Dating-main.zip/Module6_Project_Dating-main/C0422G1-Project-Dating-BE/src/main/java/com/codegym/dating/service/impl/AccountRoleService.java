package com.codegym.dating.service.impl;

import com.codegym.dating.service.IAccountRoleService;

public class AccountRoleService implements IAccountRoleService {
}
