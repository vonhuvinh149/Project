package com.codegym.dating.dto;

public interface RelationshipDto {
    int getId();
    int getStatus();
    int getIdUser1();
    int getIdUser2();
}
