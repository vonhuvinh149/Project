package com.codegym.dating.dto;

public interface ICommentDto {
    String getContent();
    Integer getIdUser();
    Integer getIdPost();
    String getName();
    String getAvatar();
}
