package com.codegym.dating.dto;

public interface ListUserDto {
    String getIdUser();
    String getName();
    String getCoin();
    String getJoinDay();
    String getTypeUser();
    String getQuantity();
}
