package com.codegym.dating.service;

public interface IRoleService {
}
