package com.codegym.dating.dto;


public interface HobbitDto {
    String getHobbitName();
}
