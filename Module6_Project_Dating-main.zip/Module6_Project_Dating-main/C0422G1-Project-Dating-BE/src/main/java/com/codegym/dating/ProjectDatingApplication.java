package com.codegym.dating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectDatingApplication {

    public static void main(String[] args) {SpringApplication.run(ProjectDatingApplication.class, args);
//        System.out.println("nhập a");
//        Scanner scanner = new Scanner(System.in);
//        String a = scanner.nextLine();
//        Integer b = Integer.parseInt(scanner.nextLine());
//        System.err.println(a);
    }

}


