package com.codegym.dating.dto;

public interface ReportDto {
    Integer getIdReport();
    String getNameReport();
}
