package com.codegym.dating.common;

public enum AuthenticationProvider {
    LOCAL, FACEBOOK
}
