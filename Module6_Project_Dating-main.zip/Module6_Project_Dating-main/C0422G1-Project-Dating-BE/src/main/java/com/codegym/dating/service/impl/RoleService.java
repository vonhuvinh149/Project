package com.codegym.dating.service.impl;

import com.codegym.dating.service.IRoleService;

public class RoleService implements IRoleService {
}
